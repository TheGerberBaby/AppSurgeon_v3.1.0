# App Surgeon - Hello-World WPF Window (Portable)
# PowerShell 5.1 compatible, no external modules.
# Run: powershell -ExecutionPolicy Bypass -File .\src\AppSurgeon\AppSurgeon.ps1

# Bootstrap: ensure Windows PowerShell (not pwsh) and STA apartment
try {
    $isCore = $PSVersionTable.PSEdition -eq 'Core'
} catch { $isCore = $false }

# Console feed (verbose/warnings/errors) appended live to a dedicated tab
function Write-ConsoleLine {
    param([string]$Text)
    $ts = (Get-Date).ToString('HH:mm:ss')
    $line = "[$ts] $Text"
    try {
        if ($null -ne $ConsoleBox -and ($ConsoleBox.PSObject.Methods.Name -contains 'AppendText')) {
            $ConsoleBox.AppendText("$line`r`n")
            $ConsoleBox.ScrollToEnd()
        }
    } catch {}
}

function Invoke-WithConsoleCapture {
    param(
        [Parameter(Mandatory=$true)][ScriptBlock]$Script,
        [string]$Context = ''
    )
    try {
        $out = & $Script 2>&1 3>&1 4>&1 5>&1 6>&1
        $prefix = if ([string]::IsNullOrEmpty($Context)) { '' } else { "[$Context] " }
        foreach ($o in $out) { Write-ConsoleLine ("{0}{1}" -f $prefix, ($o | Out-String).TrimEnd()) }
        return $true
    } catch {
        $prefix = if ([string]::IsNullOrEmpty($Context)) { '' } else { "[$Context] " }
        Write-ConsoleLine ("{0}ERROR: {1}" -f $prefix, $_.Exception.Message)
        return $false
    }
}

# Always-on residual cleanup: remove common leftover directories and shortcuts
function Get-CleanupTargets {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$false)][string]$PackageFullName
    )
    $targets = @()
    try {
        $tokens = @()
        if ($Name) { $tokens += $Name }
        if ($PackageFullName) {
            # AppX PFN often like Name_8wekyb3d8bbwe; use the part before first underscore as a hint
            $pfBase = $PackageFullName.Split('_')[0]
            if ($pfBase -and -not ($tokens -contains $pfBase)) { $tokens += $pfBase }
        }
        $tokens = $tokens | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique

        # %LOCALAPPDATA%\Packages\*
        $pkgRoot = Join-Path $env:LOCALAPPDATA 'Packages'
        if (Test-Path $pkgRoot) {
            $dirs = Get-ChildItem -Path $pkgRoot -Directory -ErrorAction SilentlyContinue
            foreach ($d in $dirs) {
                foreach ($t in $tokens) {
                    if ($d.Name -like "*$t*") { $targets += $d.FullName; break }
                }
            }
        }

        # Start Menu (All users and current user)
        $smAll = Join-Path $env:ProgramData 'Microsoft\\Windows\\Start Menu\\Programs'
        $smUsr = Join-Path $env:APPDATA      'Microsoft\\Windows\\Start Menu\\Programs'
        foreach ($sm in @($smAll, $smUsr)) {
            if (Test-Path $sm) {
                $items = Get-ChildItem -Path $sm -Recurse -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer -or $_.PSIsContainer }
                foreach ($it in $items) {
                    foreach ($t in $tokens) {
                        if ($it.Name -like "*$t*") { $targets += $it.FullName; break }
                    }
                }
            }
        }
    } catch {}
    # Distinct and existing only
    $targets = $targets | Where-Object { Test-Path $_ } | Select-Object -Unique
    return $targets
}

function Clear-Residuals {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$false)][string]$PackageFullName
    )
    $targets = Get-CleanupTargets -Name $Name -PackageFullName $PackageFullName
    if (-not $targets -or $targets.Count -eq 0) {
        Write-Log -App $Name -Type 'Info' -Action 'Cleanup' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result '' -Message 'Cleanup: no residual directories found.'
        return
    }
    foreach ($p in $targets) {
        if ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) {
            Write-Log -App $Name -Type 'Info' -Action 'Cleanup' -DryRun:$true -Result 'Success' -Message ("Dry-run: would remove residual path {0}" -f $p)
        } else {
            try {
                if ((Get-Item $p -ErrorAction SilentlyContinue).PSIsContainer) {
                    Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop
                } else {
                    Remove-Item -LiteralPath $p -Force -ErrorAction Stop
                }
                Write-Log -App $Name -Type 'Info' -Action 'Cleanup' -DryRun:$false -Result 'Success' -Message ("Real: removed residual path {0}" -f $p)
            } catch {
                Write-Log -App $Name -Type 'Info' -Action 'Cleanup' -DryRun:$false -Result 'Failed' -Message ("Real: FAILED removing residual path {0} - {1}" -f $p, $_.Exception.Message)
            }
        }
    }
}
if ($isCore) {
    $psExe = (Get-Command powershell.exe -ErrorAction SilentlyContinue).Source
    if ($psExe) {
        & $psExe -Sta -ExecutionPolicy Bypass -NoProfile -File $PSCommandPath @args
        exit $LASTEXITCODE
    }
}

# Update per-app logs in the Logs tab
function Update-DetailLog {
    if ($null -eq $DetailLog) { return }
    $DetailLog.Clear()
    $count = if ($AppList.SelectedItems) { $AppList.SelectedItems.Count } else { 0 }
    if ($count -eq 1) {
        $app = $AppList.SelectedItem.Name
        foreach ($e in $Global:LogItems) {
            if ($e.App -eq $app -or [string]::IsNullOrWhiteSpace($e.App)) { $DetailLog.AppendText(("[{0}] {1}`r`n" -f $e.Time, $e.Message)) }
        }
        $DetailLog.ScrollToEnd()
    } elseif ($count -gt 1) {
        foreach ($e in $Global:LogItems[-100..-1]) { $DetailLog.AppendText(("[{0}] {1}`r`n" -f $e.Time, $e.Message)) }
        $DetailLog.ScrollToEnd()
    } else {
        # Show recent
        $take = [Math]::Min(100, $Global:LogItems.Count)
        for ($i = $Global:LogItems.Count - $take; $i -lt $Global:LogItems.Count; $i++) {
            if ($i -ge 0) { $e = $Global:LogItems[$i]; $DetailLog.AppendText(("[{0}] {1}`r`n" -f $e.Time, $e.Message)) }
        }
        $DetailLog.ScrollToEnd()
    }
}
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    & powershell.exe -Sta -ExecutionPolicy Bypass -NoProfile -File $PSCommandPath @args
    exit $LASTEXITCODE
}

# Load required WPF assemblies
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
try { [void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing') } catch {}

# Helpers: icon resolution for AppX packages
function New-ImageSource {
    param([string]$Path)
    try {
        if (-not $Path -or -not (Test-Path $Path)) { return $null }
        $bi = New-Object System.Windows.Media.Imaging.BitmapImage
        $bi.BeginInit()
        $bi.UriSource = New-Object System.Uri($Path)
        $bi.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $bi.EndInit()
        return $bi
    } catch { return $null }
}

function Resolve-AppxIconPath {
    param(
        [string]$InstallLocation,
        [string]$Logo
    )
    if ([string]::IsNullOrWhiteSpace($InstallLocation)) { return $null }
    $candidates = @()
    if ($Logo) {
        $candidates += (Join-Path $InstallLocation $Logo)
        # Try common scale-suffixed names next to the logo
        $ext = [System.IO.Path]::GetExtension($Logo)
        $base = $Logo.Substring(0, $Logo.Length - $ext.Length)
        foreach ($q in @('scale-100','scale-125','scale-150','scale-200','targetsize-32','targetsize-44','altform-unplated')) {
            $candidates += (Join-Path $InstallLocation ("{0}.{1}{2}" -f $base, $q, $ext))
        }
    }
    # Fallback common asset names
    foreach ($name in @('Assets\\Square44x44Logo.png','Assets\\Square44x44Logo.scale-100.png','Assets\\StoreLogo.png','Square44x44Logo.png')) {
        $candidates += (Join-Path $InstallLocation $name)
    }
    foreach ($p in $candidates) { if (Test-Path $p) { return $p } }
    return $null
}

function Test-IsAdmin {
    try {
        $current = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($current)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        return $false
    }
}

# Guardrails v1: protected system components (regex, case-insensitive)
$ProtectedPatterns = @(
    '^Microsoft.Windows.ShellExperienceHost',
    '^Microsoft.Windows.StartMenuExperienceHost',
    '^Microsoft.WindowsStore', '^Microsoft.DesktopAppInstaller',
    '^Microsoft.UI.Xaml', '^Microsoft.VCLibs',
    '^Microsoft.NET.Native.(Framework|Runtime)',
    '^Microsoft\.UI\.Xaml', '^Microsoft\.VCLibs',
    '^Microsoft\.NET\.Native\.(Framework|Runtime)',
    '^MicrosoftEdgeWebView2',
    '^windows\.immersivecontrolpanel'
)

# Inline XAML for the window (Phase 2 layout)
[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="App Surgeon" Width="900" Height="600"
        ResizeMode="CanResize" WindowStartupLocation="CenterScreen"
        Background="{DynamicResource CyberBg}" Foreground="{DynamicResource CyberText}" FontSize="14">
    <!-- Cyber theme resources -->
    <Window.Resources>
        <BooleanToVisibilityConverter x:Key="BoolToVis"/>
        <!-- Brushes -->
        <SolidColorBrush x:Key="CyberBg" Color="#0F111A"/>
        <SolidColorBrush x:Key="CyberPanel" Color="#161A24"/>
        <SolidColorBrush x:Key="CyberBorder" Color="#263238"/>
        <SolidColorBrush x:Key="CyberText" Color="#E8EAED"/>
        <SolidColorBrush x:Key="CyberAccent" Color="#00E5FF"/>
        <SolidColorBrush x:Key="CyberAccentHover" Color="#18FFFF"/>
        <SolidColorBrush x:Key="CyberWarn" Color="#FF5370"/>
        <SolidColorBrush x:Key="MatrixGreen" Color="#00FF7F"/>

        <!-- TextBlock -->
        <Style TargetType="TextBlock">
            <Setter Property="Foreground" Value="{StaticResource CyberText}"/>
        </Style>

        <!-- Buttons -->
        <Style TargetType="Button">
            <Setter Property="Foreground" Value="{StaticResource CyberText}"/>
            <Setter Property="Background" Value="{StaticResource CyberPanel}"/>
            <Setter Property="BorderBrush" Value="{StaticResource CyberAccent}"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Padding" Value="10,6"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="4">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="BorderBrush" Value="{StaticResource CyberAccentHover}"/>
                            </Trigger>
                            <Trigger Property="IsEnabled" Value="False">
                                <Setter Property="Opacity" Value="0.5"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <!-- ToggleButton -->
        <Style TargetType="ToggleButton">
            <Setter Property="Foreground" Value="{StaticResource CyberText}"/>
            <Setter Property="Background" Value="{StaticResource CyberPanel}"/>
            <Setter Property="BorderBrush" Value="{StaticResource CyberAccent}"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Padding" Value="6,3"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="ToggleButton">
                        <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="4">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="BorderBrush" Value="{StaticResource CyberAccentHover}"/>
                            </Trigger>
                            <Trigger Property="IsChecked" Value="True">
                                <Setter Property="Background" Value="#11222A"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <!-- CheckBox -->
        <Style TargetType="CheckBox">
            <Setter Property="Foreground" Value="{StaticResource CyberText}"/>
        </Style>

        <!-- TextBox -->
        <Style TargetType="TextBox">
            <Setter Property="Foreground" Value="{StaticResource CyberText}"/>
            <Setter Property="Background" Value="{StaticResource CyberPanel}"/>
            <Setter Property="BorderBrush" Value="{StaticResource CyberBorder}"/>
            <Setter Property="Padding" Value="8,4"/>
            <Setter Property="VerticalContentAlignment" Value="Center"/>
            <Setter Property="CaretBrush" Value="{StaticResource MatrixGreen}"/>
            <Setter Property="SelectionBrush" Value="{StaticResource CyberAccent}"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>

        <!-- ListView -->
        <Style TargetType="ListView">
            <Setter Property="Background" Value="{StaticResource CyberPanel}"/>
            <Setter Property="BorderBrush" Value="{StaticResource CyberBorder}"/>
        </Style>

        <!-- Badge style -->
        <Style x:Key="BadgeStyle" TargetType="Border">
            <Setter Property="Background" Value="{StaticResource CyberBorder}"/>
            <Setter Property="BorderBrush" Value="{StaticResource CyberAccent}"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="CornerRadius" Value="4"/>
            <Setter Property="Padding" Value="6,2"/>
            <Setter Property="Margin" Value="8,0,0,0"/>
        </Style>

        <!-- GroupBox -->
        <Style TargetType="GroupBox">
            <Setter Property="Background" Value="{StaticResource CyberPanel}"/>
            <Setter Property="BorderBrush" Value="{StaticResource CyberBorder}"/>
        </Style>

        <!-- TabControl/TabItem -->
        <Style TargetType="TabControl">
            <Setter Property="Background" Value="{StaticResource CyberPanel}"/>
            <Setter Property="BorderBrush" Value="{StaticResource CyberBorder}"/>
        </Style>
        <Style TargetType="TabItem">
            <Setter Property="Foreground" Value="{StaticResource CyberText}"/>
            <Setter Property="Background" Value="{StaticResource CyberPanel}"/>
            <Setter Property="BorderBrush" Value="{StaticResource CyberBorder}"/>
            <Setter Property="Padding" Value="12,6"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="TabItem">
                        <Border x:Name="Bd" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" CornerRadius="4" Padding="2" Margin="2,2,2,0">
                            <ContentPresenter ContentSource="Header" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsSelected" Value="True">
                                <Setter TargetName="Bd" Property="Background" Value="#161A24"/>
                                <Setter Property="BorderBrush" Value="{StaticResource CyberAccent}"/>
                                <Setter Property="Foreground" Value="{StaticResource MatrixGreen}"/>
                            </Trigger>
                            <Trigger Property="IsEnabled" Value="False">
                                <Setter TargetName="Bd" Property="Opacity" Value="0.6"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>

    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="150"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="2*"/>
            <ColumnDefinition Width="*"/>
        </Grid.ColumnDefinitions>

        <!-- Top toolbar with Search and options -->
        <StackPanel Grid.Row="0" Grid.ColumnSpan="2" Orientation="Horizontal" Margin="8" HorizontalAlignment="Left">
            <Button x:Name="RefreshBtn" Content="Refresh" Height="30" Width="90" Margin="0,0,8,0"/>
            <TextBlock Text="Search:" VerticalAlignment="Center" Margin="8,0,4,0"/>
            <TextBox x:Name="SearchBox" MinWidth="280" Height="32"/>
            <CheckBox x:Name="AllUsersToggle" Content="All Users" Margin="12,0,0,0" VerticalAlignment="Center"/>
            <CheckBox x:Name="DeepRemoveToggle" Content="Deep Remove" Margin="8,0,0,0" VerticalAlignment="Center"/>
            <ToggleButton x:Name="DryRunToggle" Content="Dry Run (On)" IsChecked="True" Height="30" Margin="8,0,0,0" MinWidth="120"/>
        </StackPanel>

        <!-- Left pane: Apps list -->
        <Grid Grid.Row="1" Grid.Column="0" Margin="8">
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
            </Grid.RowDefinitions>
            <TextBlock Grid.Row="0" Text="Apps" FontSize="16" FontWeight="Bold" Margin="0,0,0,6"/>
            <ListView Grid.Row="1" x:Name="AppList" SelectionMode="Extended"
                      ScrollViewer.VerticalScrollBarVisibility="Auto"
                      ScrollViewer.CanContentScroll="True">
                <ListView.ItemContainerStyle>
                    <Style TargetType="ListViewItem">
                        <Setter Property="IsEnabled" Value="{Binding IsEnabled}"/>
                        <Setter Property="MinHeight" Value="34"/>
                        <Setter Property="Padding" Value="4"/>
                    </Style>
                </ListView.ItemContainerStyle>
                <ListView.ItemTemplate>
                    <DataTemplate>
                        <DockPanel LastChildFill="True">
                            <CheckBox DockPanel.Dock="Left"
                                      IsChecked="{Binding RelativeSource={RelativeSource AncestorType=ListViewItem}, Path=IsSelected, Mode=TwoWay}"
                                      IsEnabled="{Binding IsEnabled}" Margin="0,0,8,0"/>
                            <Image DockPanel.Dock="Left" Width="20" Height="20" Margin="0,0,8,0" Source="{Binding Icon}"/>
                            <Grid VerticalAlignment="Center">
                                <Grid.ColumnDefinitions>
                                    <ColumnDefinition Width="*"/>
                                    <ColumnDefinition Width="Auto"/>
                                </Grid.ColumnDefinitions>
                                <TextBlock Grid.Column="0" Text="{Binding Title}" FontSize="14" FontWeight="Bold" TextTrimming="CharacterEllipsis" Foreground="{StaticResource MatrixGreen}"/>
                                <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
                                    <Border Style="{StaticResource BadgeStyle}"><TextBlock Text="{Binding Type}" Foreground="{StaticResource MatrixGreen}"/></Border>
                                    <Border Style="{StaticResource BadgeStyle}" Visibility="{Binding Protected, Converter={StaticResource BoolToVis}}"><TextBlock Text="Protected" Foreground="{StaticResource MatrixGreen}"/></Border>
                                </StackPanel>
                            </Grid>
                        </DockPanel>
                    </DataTemplate>
                </ListView.ItemTemplate>
            </ListView>
        </Grid>

        <!-- Right pane: Details/Logs and actions -->
        <StackPanel Grid.Row="1" Grid.Column="1" Margin="8" Orientation="Vertical">
            <TabControl>
                <TabItem Header="Details">
                    <ScrollViewer VerticalScrollBarVisibility="Auto">
                        <StackPanel Margin="8">
                            <TextBlock Text="Name:" FontWeight="Bold"/>
                            <TextBlock x:Name="DetailName" Margin="0,0,0,6" TextAlignment="Center" FontSize="14" FontWeight="Bold"/>
                            <TextBlock Text="Version:" FontWeight="Bold"/>
                            <TextBlock x:Name="DetailVersion" Margin="0,0,0,6"/>
                            <TextBlock Text="Path:" FontWeight="Bold"/>
                            <TextBlock x:Name="DetailPath" Margin="0,0,0,6" TextWrapping="Wrap"/>
                            <TextBlock Text="Uninstall String:" FontWeight="Bold"/>
                            <TextBox x:Name="DetailUninstall" Margin="0,0,0,6" IsReadOnly="True" TextWrapping="Wrap" Height="48"/>
                            <TextBlock Text="Size:" FontWeight="Bold"/>
                            <TextBlock x:Name="DetailSize"/>
                            <TextBlock x:Name="DetailNote" Margin="0,6,0,0" Foreground="Tomato"/>
                        </StackPanel>
                    </ScrollViewer>
                </TabItem>
                <TabItem Header="Logs">
                    <TextBox x:Name="DetailLog" Margin="8" IsReadOnly="True" AcceptsReturn="True" TextWrapping="NoWrap" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"/>
                </TabItem>
                <TabItem Header="Console">
                    <TextBox x:Name="ConsoleBox" Margin="8" IsReadOnly="True" AcceptsReturn="True" TextWrapping="NoWrap" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"/>
                </TabItem>
            </TabControl>
            <StackPanel Orientation="Horizontal" Margin="0,8,0,0">
                <Button x:Name="RemoveBtn" Content="Remove Selected" IsEnabled="False" Height="36" Width="160" Margin="0,0,8,0"/>
                <Button x:Name="SaveLogsBtn" Content="Save Logs..." Height="36" Width="120" />
            </StackPanel>
        </StackPanel>

        <!-- Bottom log box -->
        <TextBox x:Name="LogBox" Grid.Row="2" Grid.ColumnSpan="2" Margin="8" IsReadOnly="True" AcceptsReturn="True"
                 VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto" TextWrapping="NoWrap"/>

        <!-- Status bar at very bottom -->
        <StatusBar Grid.Row="3" Grid.ColumnSpan="2">
            <StatusBarItem>
                <TextBlock x:Name="StatusText" Text="Simulation Only" Foreground="Green" FontWeight="Bold"/>
            </StatusBarItem>
        </StatusBar>
    </Grid>
</Window>
'@

# Parse XAML and get named controls
$reader = New-Object System.Xml.XmlNodeReader($xaml)
$window = [System.Windows.Markup.XamlReader]::Load($reader)

# Helper to resolve named controls from window scope
function Get-Ui {
    param([string]$Name)
    $ctrl = $window.FindName($Name)
    if (-not $ctrl) { $ctrl = [System.Windows.LogicalTreeHelper]::FindLogicalNode($window, $Name) }
    return $ctrl
}

$AppList       = Get-Ui -Name 'AppList'
$DryRunToggle  = Get-Ui -Name 'DryRunToggle'
$RemoveBtn     = Get-Ui -Name 'RemoveBtn'
$LogBox        = Get-Ui -Name 'LogBox'
$DetailName    = Get-Ui -Name 'DetailName'
$DetailVersion = Get-Ui -Name 'DetailVersion'
$DetailSize    = Get-Ui -Name 'DetailSize'
$StatusText    = Get-Ui -Name 'StatusText'
$DetailNote    = Get-Ui -Name 'DetailNote'
$SaveLogsBtn   = Get-Ui -Name 'SaveLogsBtn'
$RefreshBtn    = Get-Ui -Name 'RefreshBtn'
$SearchBox     = Get-Ui -Name 'SearchBox'
$DetailPath    = Get-Ui -Name 'DetailPath'
$DetailUninstall = Get-Ui -Name 'DetailUninstall'
$AllUsersToggle  = Get-Ui -Name 'AllUsersToggle'
$DeepRemoveToggle = Get-Ui -Name 'DeepRemoveToggle'
$DetailLog       = Get-Ui -Name 'DetailLog'

# Fallback: if DryRunToggle is missing from XAML, create a logical placeholder so code paths remain safe
if (-not $DryRunToggle) {
    try {
        $DryRunToggle = New-Object System.Windows.Controls.Primitives.ToggleButton
        $DryRunToggle.IsChecked = $true
        $DryRunToggle.Content = 'Dry Run (On)'
    } catch {}
}

# Structured logging
$Global:LogItems = @()

function Write-Log {
    param(
        [string]$App = '',
        [string]$Type = '',     # Installed | Provisioned | Info
        [string]$Action = '',   # Remove | Discover | Info
        [bool]  $DryRun = $true,
        [string]$Result = '',   # Success | Failed | Skipped | ''
        [string]$Message = ''
    )
    $timeIso = (Get-Date).ToString('s')
    $timeDisp = (Get-Date).ToString('HH:mm:ss')
    $entry = [pscustomobject]@{
        Time    = $timeIso
        App     = $App
        Type    = $Type
        Action  = $Action
        DryRun  = $DryRun
        Result  = $Result
        Message = $Message
    }
    $Global:LogItems += $entry
    $line = "[$timeDisp] $Message"
    if ($null -ne $LogBox -and ($LogBox.PSObject.Methods.Name -contains 'AppendText')) {
        $LogBox.AppendText("$line`r`n")
        $LogBox.ScrollToEnd()
    }
    # Live update the Logs tab content
    try { Update-DetailLog } catch {}
}

# Ensure Logs directory and write logs to TXT + JSON
function Save-Logs {
    try {
        $scriptDir = Split-Path -Parent $PSCommandPath
        $LogDir = Join-Path -Path $scriptDir -ChildPath 'Logs'
        if (-not (Test-Path $LogDir)) { $null = New-Item -ItemType Directory -Path $LogDir }
        $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
        $txt = Join-Path $LogDir "AppSurgeon_$stamp.txt"
        $json = Join-Path $LogDir "AppSurgeon_$stamp.json"
        $lines = $Global:LogItems | ForEach-Object {
            $t = try { [datetime]::Parse($_.Time).ToString('HH:mm:ss') } catch { $_.Time }
            "[$t] $($_.Message)"
        }
        Set-Content -Path $txt -Value $lines -Encoding UTF8
        $Global:LogItems | ConvertTo-Json -Depth 4 | Set-Content -Path $json -Encoding UTF8
        Write-Log -App '' -Type 'Info' -Action 'SaveLogs' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result 'Success' -Message "Saved logs to: $txt, $json"
    } catch {
        Write-Log -App '' -Type 'Info' -Action 'SaveLogs' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result 'Failed' -Message ("Failed to save logs - {0}" -f $_.Exception.Message)
    }
}

# Removal helpers (return $true on success, $false on failure)
function Remove-InstalledAppx {
    param(
        [Parameter(Mandatory=$true)][string]$PackageFullName,
        [Parameter(Mandatory=$true)][string]$Name
    )
    if ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) {
        Write-Log -App $Name -Type 'Installed' -Action 'Remove' -DryRun:$true -Result 'Success' -Message "Dry-run: would remove installed $Name"
        return $true
    }
    try {
        if ($AllUsersToggle -and $AllUsersToggle.IsChecked) {
            $null = Invoke-WithConsoleCapture -Context "Remove-AppxPackage(AllUsers) $Name" -Script { Remove-AppxPackage -Package $PackageFullName -AllUsers -ErrorAction Stop }
        } else {
            $null = Invoke-WithConsoleCapture -Context "Remove-AppxPackage $Name" -Script { Remove-AppxPackage -Package $PackageFullName -ErrorAction Stop }
        }
        Write-Log -App $Name -Type 'Installed' -Action 'Remove' -DryRun:$false -Result 'Success' -Message "Real: removed installed $Name"
        return $true
    } catch {
        $err = $_
        Write-ConsoleLine ("[Remove-AppxPackage ERROR] {0}" -f ($err | Out-String))
        $detail = "Real: FAILED removing installed {0} - {1} (Category: {2}; FQID: {3})" -f $Name, $err.Exception.Message, $err.CategoryInfo, $err.FullyQualifiedErrorId
        Write-Log -App $Name -Type 'Installed' -Action 'Remove' -DryRun:$false -Result 'Failed' -Message $detail
        return $false
    }
}

function Remove-ProvisionedAppx {
    param(
        [Parameter(Mandatory=$true)][string]$PackageName,
        [Parameter(Mandatory=$true)][string]$Name
    )
    if ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) {
        Write-Log -App $Name -Type 'Provisioned' -Action 'Remove' -DryRun:$true -Result 'Success' -Message "Dry-run: would deprovision $Name"
        return $true
    }
    try {
        $null = Invoke-WithConsoleCapture -Context "Remove-AppxProvisionedPackage $Name" -Script { Remove-AppxProvisionedPackage -Online -PackageName $PackageName -ErrorAction Stop | Out-Null }
        Write-Log -App $Name -Type 'Provisioned' -Action 'Remove' -DryRun:$false -Result 'Success' -Message "Real: deprovisioned $Name"
        return $true
    } catch {
        $err = $_
        Write-ConsoleLine ("[Remove-AppxProvisionedPackage ERROR] {0}" -f ($err | Out-String))
        $detail = "Real: FAILED deprovisioning {0} - {1} (Category: {2}; FQID: {3})" -f $Name, $err.Exception.Message, $err.CategoryInfo, $err.FullyQualifiedErrorId
        Write-Log -App $Name -Type 'Provisioned' -Action 'Remove' -DryRun:$false -Result 'Failed' -Message $detail
        return $false
    }
}

# Update details pane based on selection
function Update-Details {
    $count = if ($AppList.SelectedItems) { $AppList.SelectedItems.Count } else { 0 }
    if ($count -eq 1) {
        $sel = $AppList.SelectedItem
        $name = $sel.Name
        $DetailName.Text = "$name"
        $DetailVersion.Text = $sel.PackageFullName
        $DetailSize.Text = $sel.Type
        $DetailPath.Text = ($sel.Path | Out-String).Trim()
        $DetailUninstall.Text = ($sel.UninstallString | Out-String).Trim()
        if ($sel.Protected) {
            $DetailNote.Text = 'System component — removal blocked.'
        } else {
            $DetailNote.Text = ''
        }
    } elseif ($count -gt 1) {
        $DetailName.Text = "Multiple selected ($count)"
        $DetailVersion.Text = ''
        $DetailSize.Text = ''
        $DetailPath.Text = ''
        $DetailUninstall.Text = ''
        $DetailNote.Text = ''
    } else {
        $DetailName.Text = ''
        $DetailVersion.Text = ''
        $DetailSize.Text = ''
        $DetailPath.Text = ''
        $DetailUninstall.Text = ''
        $DetailNote.Text = ''
    }
}

# Selection changed: enable/disable Remove button and update details
$null = $AppList.add_SelectionChanged({
    if ($AppList.SelectedItems -and $AppList.SelectedItems.Count -gt 0) {
        $RemoveBtn.IsEnabled = $true
    } else {
        $RemoveBtn.IsEnabled = $false
    }
    Update-Details
    Update-DetailLog
})

# Toggle button: update content text and status indicator
function Update-StatusIndicator {
    if ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) {
        $StatusText.Text = 'Simulation Only'
        $StatusText.Foreground = 'Green'
        if ($DryRunToggle) { $DryRunToggle.Content = 'Dry Run (On)' }
    } else {
        $StatusText.Text = 'Live Mode'
        $StatusText.Foreground = 'Red'
        if ($DryRunToggle) { $DryRunToggle.Content = 'Dry Run (Off)' }
    }
}
$null = if ($DryRunToggle -and ($DryRunToggle.PSObject.Methods.Name -contains 'add_Click')) { $DryRunToggle.add_Click({
    # If toggling OFF Dry-Run, confirm with the user.
    if (-not ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true)) {
        $res = [System.Windows.MessageBox]::Show(
            "You are switching to LIVE removals. Changes cannot be undone easily. Continue?",
            "Confirm Live Mode",
            [System.Windows.MessageBoxButton]::YesNo,
            [System.Windows.MessageBoxImage]::Warning
        )
        if ($res -ne [System.Windows.MessageBoxResult]::Yes) {
            $DryRunToggle.IsChecked = $true
        }
    }
    Update-StatusIndicator
}) }

# Remove button click: log action for all selected
$null = $RemoveBtn.add_Click({
    if (-not ($AppList.SelectedItems) -or $AppList.SelectedItems.Count -eq 0) { return }
    # Freeze current selection to avoid mutation issues during iteration
    $targets = @($AppList.SelectedItems)
    foreach ($sel in $targets) {
        $name = $sel.Name
        if ([string]::IsNullOrWhiteSpace($name)) { $name = '<unknown>' }
        if ($sel.Protected) {
            Write-Log -App $name -Type $sel.Type -Action 'Remove' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result 'Skipped' -Message "Skipped - protected system component: $name"
            continue
        }

        $ok = $false
        switch ($sel.Type) {
            'Installed' {
                $ok = Remove-InstalledAppx -PackageFullName $sel.PackageFullName -Name $name
                if ($ok -and -not ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true)) {
                    # Verify removal
                    $stillThere = @(Get-AppxPackage -AllUsers | Where-Object { $_.PackageFullName -eq $sel.PackageFullName })
                    if ($stillThere.Count -eq 0) { $AppList.ItemsSource.Remove($sel) | Out-Null }
                }
                # Optional deprovision if DeepRemove is enabled
                if ($ok -and $DeepRemoveToggle -and $DeepRemoveToggle.IsChecked) {
                    try {
                        if ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) {
                            Write-Log -App $name -Type 'Provisioned' -Action 'Remove' -DryRun:$true -Result 'Success' -Message "Dry-run: would deprovision any matching provisioned package for $name"
                        } else {
                            $prov = @(Get-AppxProvisionedPackage -Online | Where-Object { $_.DisplayName -like "$name*" -or $_.PackageName -like "*$($sel.Name)*" })
                            foreach ($pv in $prov) {
                                try { Remove-AppxProvisionedPackage -Online -PackageName $pv.PackageName -ErrorAction Stop | Out-Null; Write-Log -App $name -Type 'Provisioned' -Action 'Remove' -DryRun:$false -Result 'Success' -Message ("Real: deprovisioned {0}" -f $pv.PackageName) } catch { Write-Log -App $name -Type 'Provisioned' -Action 'Remove' -DryRun:$false -Result 'Failed' -Message ("Real: FAILED deprovisioning {0} - {1}" -f $pv.PackageName, $_.Exception.Message) }
                            }
                        }
                    } catch { Write-Log -App $name -Type 'Provisioned' -Action 'Remove' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result 'Failed' -Message ("Deep deprovision check failed - {0}" -f $_.Exception.Message) }
                }
            }
            'Provisioned' {
                $ok = Remove-ProvisionedAppx -PackageName $sel.PackageFullName -Name $name
                if ($ok -and -not ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true)) {
                    # Verify removal
                    $stillThere = @(Get-AppxProvisionedPackage -Online | Where-Object { $_.PackageName -eq $sel.PackageFullName })
                    if ($stillThere.Count -eq 0) { $AppList.ItemsSource.Remove($sel) | Out-Null }
                }
            }
            default {
                Write-Log -App $name -Type $sel.Type -Action 'Remove' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result 'Skipped' -Message "Skipped - unknown type for $name"
            }
        }

        $verb = if ($sel.Type -eq 'Provisioned') { 'deprovision' } else { 'remove' }
        $result = if ($ok) { 'Success' } else { 'Failed' }
        $prefix = if ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) { 'Dry-run' } else { 'Real' }
        Write-Log -App $name -Type $sel.Type -Action 'Remove' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result $result -Message ("{0}: {1} {2} - {3}" -f $prefix, $verb, $name, $result)

        # Deep capability removal (optional)
        if ($DeepRemoveToggle -and $DeepRemoveToggle.IsChecked) {
            try {
                $caps = Get-WindowsCapability -Online | Where-Object { $_.Name -match $name -or $_.Name -match $sel.Name }
            } catch { $caps = @(); Write-Log -App $name -Type 'Info' -Action 'Discover' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result 'Failed' -Message ("Capability discovery failed - {0}" -f $_.Exception.Message) }
            if ($caps.Count -gt 0) {
                $listCaps = ($caps | Select-Object -ExpandProperty Name) -join "`r`n"
                $doRemove = $true
                if (-not ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true)) {
                    $msg = "Deep Remove: remove related Windows capabilities?`r`n`r`n$listCaps"
                    $res = [System.Windows.MessageBox]::Show($msg, 'Confirm Capability Removal', [System.Windows.MessageBoxButton]::YesNo, [System.Windows.MessageBoxImage]::Warning)
                    $doRemove = ($res -eq [System.Windows.MessageBoxResult]::Yes)
                }
                if ($doRemove) {
                    foreach ($c in $caps) {
                        if ($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) {
                            Write-Log -App $name -Type 'Info' -Action 'Capability' -DryRun:$true -Result 'Success' -Message ("Dry-run: would remove capability {0}" -f $c.Name)
                        } else {
                            try { Remove-WindowsCapability -Online -Name $c.Name -ErrorAction Stop | Out-Null; Write-Log -App $name -Type 'Info' -Action 'Capability' -DryRun:$false -Result 'Success' -Message ("Real: removed capability {0}" -f $c.Name) } catch { Write-Log -App $name -Type 'Info' -Action 'Capability' -DryRun:$false -Result 'Failed' -Message ("Real: FAILED removing capability {0} - {1}" -f $c.Name, $_.Exception.Message) }
                        }
                    }
                }
            }
        }

        Start-Sleep -Seconds 2

        # Always perform residual cleanup
        Clear-Residuals -Name $name -PackageFullName $sel.PackageFullName
    }
    # Persist logs for this run
    Save-Logs
})

# Window Loaded: initial messages, admin check, and initial indicators
function Update-AppList {
    Write-Log -Type 'Info' -Action 'Init' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result '' -Message 'App Surgeon initialized.'
    if (-not (Test-IsAdmin)) {
        Write-Log -Type 'Info' -Action 'Init' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result '' -Message 'Notice: Not elevated - admin-required actions disabled.'
    }
    try {
        $installed = @(Get-AppxPackage -AllUsers | Select-Object -Property Name, PackageFullName, InstallLocation, Logo)
    } catch {
        $installed = @()
        Write-Log -Type 'Info' -Action 'Discover' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result 'Failed' -Message ("Warning: Get-AppxPackage failed: {0}" -f $_.Exception.Message)
    }
    try {
        $provisioned = @(Get-AppxProvisionedPackage -Online | Select-Object -Property DisplayName, PackageName)
    } catch {
        $provisioned = @()
        Write-Log -Type 'Info' -Action 'Discover' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result 'Failed' -Message ("Warning: Get-AppxProvisionedPackage failed: {0}" -f $_.Exception.Message)
    }
    $list = New-Object System.Collections.ObjectModel.ObservableCollection[object]
    foreach ($p in $installed) {
        $isProtected = $false; foreach ($pat in $ProtectedPatterns) { if ($p.Name -match $pat -or $p.PackageFullName -match $pat) { $isProtected = $true; break } }
        $iconPath = Resolve-AppxIconPath -InstallLocation $p.InstallLocation -Logo $p.Logo
        if (-not $iconPath -and $p.InstallLocation) {
            # Extra common icon fallbacks
            foreach ($extra in @('Assets\\Logo.png','Assets\\AppList.png')) { $try = Join-Path $p.InstallLocation $extra; if (Test-Path $try) { $iconPath = $try; break } }
        }
        $iconSrc = New-ImageSource -Path $iconPath
        $title = if ([string]::IsNullOrWhiteSpace($p.Name)) { ($p.PackageFullName -split '_')[0] } else { $p.Name }
        $suffix = if ($isProtected) { ' (Installed, Protected)' } else { ' (Installed)' }
        $display = "$title$suffix"
        $obj = [pscustomobject]@{
            Display         = $display
            Title           = $title
            Suffix          = $suffix
            Name            = $title
            PackageFullName = $p.PackageFullName
            Type            = 'Installed'
            Protected       = $isProtected
            IsEnabled       = (-not $isProtected)
            Icon            = $iconSrc
            Path            = $p.InstallLocation
            UninstallString = ("powershell -NoProfile -Command `"Remove-AppxPackage -Package '{0}'`"" -f $p.PackageFullName)
        }
        $list.Add($obj) | Out-Null
    }
    foreach ($p in $provisioned) {
        $isProtected = $false; foreach ($pat in $ProtectedPatterns) { if ($p.DisplayName -match $pat -or $p.PackageName -match $pat) { $isProtected = $true; break } }
        $title = if ([string]::IsNullOrWhiteSpace($p.DisplayName)) { ($p.PackageName -split '_')[0] } else { $p.DisplayName }
        $suffix = if ($isProtected) { ' (Provisioned, Protected)' } else { ' (Provisioned)' }
        $display = "$title$suffix"
        $obj = [pscustomobject]@{
            Display         = $display
            Title           = $title
            Suffix          = $suffix
            Name            = $title
            PackageFullName = $p.PackageName
            Type            = 'Provisioned'
            Protected       = $isProtected
            IsEnabled       = (-not $isProtected)
            Icon            = $null
            Path            = ''
            UninstallString = ("powershell -NoProfile -Command `"Remove-AppxProvisionedPackage -Online -PackageName '{0}'`"" -f $p.PackageName)
        }
        $list.Add($obj) | Out-Null
    }
    $Global:AllApps = $list
    Update-Filter
}

function Update-Filter {
    $term = ($SearchBox.Text | Out-String).Trim()
    if (-not $Global:AllApps) { return }
    if ([string]::IsNullOrWhiteSpace($term)) {
        $AppList.ItemsSource = $Global:AllApps
        return
    }
    $regex = [regex]::Escape($term)
    $filtered = New-Object System.Collections.ObjectModel.ObservableCollection[object]
    foreach ($it in $Global:AllApps) {
        if ($it.Name -match $regex -or $it.Title -match $regex -or $it.Display -match $regex -or $it.PackageFullName -match $regex) {
            $null = $filtered.Add($it)
        }
    }
    $AppList.ItemsSource = $filtered
}

$null = $window.add_Loaded({
    Update-AppList
    Update-StatusIndicator
    Update-Details
})

$null = $RefreshBtn.add_Click({ Update-AppList })

# Search live filtering
if ($null -ne $SearchBox) {
    $null = $SearchBox.add_TextChanged({ Update-Filter })
}

# Save Logs button
$null = $SaveLogsBtn.add_Click({ Save-Logs })

# Headless helper for smoke tests: performs discovery and optional dry-run removals, then saves logs.
function Invoke-AppSurgeonHeadless {
    param(
        [switch]$Live,
        [int]$Limit = 3
    )
    # Mock DryRunToggle if UI not loaded
    if ($null -eq $DryRunToggle) { $Global:DryRunToggle = [pscustomobject]@{ IsChecked = (-not $Live.IsPresent) } }

    Write-Log -Type 'Info' -Action 'Headless' -DryRun:$DryRunToggle.IsChecked -Result '' -Message ("Headless start - Mode: {0}, Limit: {1}" -f $(if ($DryRunToggle.IsChecked) { 'Dry-Run' } else { 'Live' }), $Limit)

    # Discovery (re-using patterns)
    try { $installed = @(Get-AppxPackage -AllUsers | Select-Object -Property Name, PackageFullName) } catch { $installed = @(); Write-Log -Type 'Info' -Action 'Discover' -DryRun:$DryRunToggle.IsChecked -Result 'Failed' -Message ("Warning: Get-AppxPackage failed: {0}" -f $_.Exception.Message) }
    try { $provisioned = @(Get-AppxProvisionedPackage -Online | Select-Object -Property DisplayName, PackageName) } catch { $provisioned = @(); Write-Log -Type 'Info' -Action 'Discover' -DryRun:$DryRunToggle.IsChecked -Result 'Failed' -Message ("Warning: Get-AppxProvisionedPackage failed: {0}" -f $_.Exception.Message) }

    $items = @()
    foreach ($p in $installed) {
        $isProtected = $false; foreach ($pat in $ProtectedPatterns) { if ($p.Name -match $pat -or $p.PackageFullName -match $pat) { $isProtected = $true; break } }
        $items += [pscustomobject]@{ Name=$p.Name; PackageFullName=$p.PackageFullName; Type='Installed'; Protected=$isProtected }
    }
    foreach ($p in $provisioned) {
        $isProtected = $false; foreach ($pat in $ProtectedPatterns) { if ($p.DisplayName -match $pat -or $p.PackageName -match $pat) { $isProtected = $true; break } }
        $items += [pscustomobject]@{ Name=$p.DisplayName; PackageFullName=$p.PackageName; Type='Provisioned'; Protected=$isProtected }
    }

    $targets = $items | Where-Object { -not $_.Protected } | Select-Object -First $Limit
    foreach ($t in $targets) {
        switch ($t.Type) {
            'Installed'   { $null = Remove-InstalledAppx -PackageFullName $t.PackageFullName -Name $t.Name }
            'Provisioned' { $null = Remove-ProvisionedAppx -PackageName    $t.PackageFullName -Name $t.Name }
        }
        Start-Sleep -Milliseconds 500
    }
    Save-Logs
    Write-Log -Type 'Info' -Action 'Headless' -DryRun:($DryRunToggle -and $DryRunToggle.IsChecked -eq $true) -Result 'Success' -Message 'Headless run complete.'
}

# Show window (modal) unless running headless
if (-not $Global:AppSurgeon_Headless) {
    $null = $window.ShowDialog()
}
