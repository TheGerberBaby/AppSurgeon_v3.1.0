# Smoke tests for App Surgeon (Phase 7)
# PowerShell 5.1 compatible; non-destructive by default
param(
    [switch]$Live,
    [int]$Limit = 3
)

$ErrorActionPreference = 'Stop'

function Write-Result {
    param([string]$Status, [string]$Message)
    $ts = (Get-Date).ToString('HH:mm:ss')
    Write-Host "[$ts] [$Status] $Message"
}

try {
    # Resolve repo root
    $ScriptDir = Split-Path -Parent $PSCommandPath
    $Root      = Split-Path -Parent $ScriptDir
    $AppScript = Join-Path $Root 'src\AppSurgeon\AppSurgeon.ps1'
    if (-not (Test-Path $AppScript)) { throw "AppSurgeon.ps1 not found at: $AppScript" }

    # Ensure headless mode and dot-source the script so we can call helpers
    $Global:AppSurgeon_Headless = $true
    . $AppScript

    # Run headless flow (Dry-Run by default unless -Live specified)
    Invoke-AppSurgeonHeadless -Live:$Live.IsPresent -Limit $Limit

    # Basic guardrails presence check (discovery-level)
    $hasProtected = $false
    try {
        $installed = @(Get-AppxPackage -AllUsers | Select-Object -Property Name, PackageFullName)
        $provisioned = @(Get-AppxProvisionedPackage -Online | Select-Object -Property DisplayName, PackageName)
        foreach ($p in $installed) {
            foreach ($pat in $ProtectedPatterns) { if ($p.Name -match $pat -or $p.PackageFullName -match $pat) { $hasProtected = $true; break } }
            if ($hasProtected) { break }
        }
        if (-not $hasProtected) {
            foreach ($p in $provisioned) {
                foreach ($pat in $ProtectedPatterns) { if ($p.DisplayName -match $pat -or $p.PackageName -match $pat) { $hasProtected = $true; break } }
                if ($hasProtected) { break }
            }
        }
    } catch {
        # Non-fatal for smoke test
    }

    # Validate logs: 2 files with today's date, and JSON parses
    $logDir = Join-Path (Split-Path -Parent $AppScript) 'Logs'
    if (-not (Test-Path $logDir)) { throw "Log directory not found: $logDir" }

    $today = (Get-Date).ToString('yyyyMMdd')
    $txts = Get-ChildItem -Path $logDir -Filter "AppSurgeon_${today}_*.txt" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
    $jsons = Get-ChildItem -Path $logDir -Filter "AppSurgeon_${today}_*.json" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending

    if (-not $txts -or -not $jsons) { throw "Expected TXT/JSON logs with today's date ($today) in $logDir" }

    $latestTxt = $txts[0].FullName
    $latestJson = $jsons[0].FullName

    if ((Get-Item $latestTxt).Length -le 0) { throw "TXT log is empty: $latestTxt" }
    $jsonContent = Get-Content -Path $latestJson -Raw -ErrorAction Stop
    $parsed = $null
    try { $parsed = $jsonContent | ConvertFrom-Json -ErrorAction Stop } catch { throw ("JSON parse failed: {0} - {1}" -f $latestJson, $_.Exception.Message) }
    if ($null -eq $parsed -or $parsed.Count -lt 1) { throw "JSON log has no entries: $latestJson" }

    # Summarize
    Write-Result 'PASS' ('Headless run complete. Logs verified (TXT/JSON). Mode: {0}, Limit: {1}' -f ($(if ($Live) {'Live'} else {'Dry-Run'})), $Limit)
    if ($hasProtected) {
        Write-Result 'PASS' 'Guardrails present: protected patterns detected in discovery.'
    } else {
        Write-Result 'WARN' 'No protected items detected during discovery on this machine.'
    }

    exit 0
} catch {
    Write-Result 'FAIL' $_.Exception.Message
    exit 1
}
